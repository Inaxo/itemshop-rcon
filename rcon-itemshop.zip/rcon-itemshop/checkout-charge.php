<?php
require_once('mainconfig.php');
?>
<html lang="pl">
<head>

	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
	
  <title><?php echo $server_name;?> | <?php echo $server_desc;?></title>
      	<meta http-equiv="X-Ua-Compatible" content="IE=edge">
        <meta name="description" content=" <?php echo $server_desc;?>">
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
        <meta property="og:site_name" content="<?php echo $server_name;?>">
        <meta property="og:title" content="<?php echo $server_name;?> | <?php echo $server_desc;?>">
        <meta name="author" content="DenCode.pl">
        <meta property="og:type" content="website">
        <!--  <meta property="og:url" content="https://nazwamc.pl/"> !-->
        <meta property="og:description" content=" <?php echo $server_desc;?>">
        <meta name="theme-color" content="#a750e8">
        <link rel="icon" type="image/png" href="assets/img/favicon.png">
        <link rel="stylesheet" href="libs/bootstrap.min.css">
        <link rel="stylesheet" href="assets/css/main.css">
        <link href="https://fonts.googleapis.com/css?family=Open+Sans:400,700&amp;subset=latin-ext" rel="stylesheet">
        <link rel="preconnect" href="https://fonts.googleapis.com">
        <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
        <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@800&display=swap" rel="stylesheet">
        <link href="https://unpkg.com/aos@2.3.1/dist/aos.css" rel="stylesheet">
        <script src="https://js.stripe.com/v3/"></script>
	<!--[if lt IE 9]>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/html5shiv/3.7.3/html5shiv.min.js"></script>
	<![endif]--> 
	
</head>
<body>
<?php
    include("./config.php");

    $token = $_POST["stripeToken"];
    
    $token_card_type = $_POST["stripeTokenType"];
    $email           = $_POST["stripeEmail"];
    $amount          = $_POST["amount"];
     
    $desc            = $_POST["product_name"];
    $playername = $_POST["nickname"];
    $charge = \Stripe\Charge::create([
      "amount" => str_replace(",","",$amount) * 100,
      "currency" => 'pln',
      "description"=>$desc,
      "source"=> $token,
    ]);

    if($charge && $playername!=null){
      header("Location:success.php?amount=$amount"."&playername=$playername"."&name=$desc");
    }else {
      echo "<span style='color:red; display:flex; justify-content:center; align-items:center;'>Nie podano nazwy użytkownika! Transakcja anulowana!</span></br>";
      echo '<a href="shop" style="text-decoration:none; color:white;"><span style="font-size: 20px; display: flex; justify-content:center; ">Powrót do produktów</span></a>';
    }

    
?>

</body>
</html>