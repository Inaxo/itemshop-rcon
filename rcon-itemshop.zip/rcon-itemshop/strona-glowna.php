<?php
require_once('mainconfig.php');
?>

<!DOCTYPE html>
<html lang="pl">
<head>

	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
	
        <title><?php echo $server_name;?> | <?php echo $server_desc;?></title>
      	<meta http-equiv="X-Ua-Compatible" content="IE=edge">
        <meta name="description" content=" <?php echo $server_desc;?>">
        <meta property="og:site_name" content="<?php echo $server_name;?>">
        <meta property="og:title" content="<?php echo $server_name;?> | <?php echo $server_desc;?>">
        <meta name="author" content="DenCode.pl">
        <meta property="og:type" content="website">
        <!--  <meta property="og:url" content="https://twojanazwa.pl/"> !-->
        <meta property="og:description" content=" <?php echo $server_desc;?>">
        <meta name="theme-color" content="#a750e8">
        <link rel="icon" type="image/png" href="assets/img/favicon.png">
        <link rel="stylesheet" href="libs/bootstrap.min.css">
        <link rel="stylesheet" href="assets/css/main.css">
        <link href="https://fonts.googleapis.com/css?family=Open+Sans:400,700&amp;subset=latin-ext" rel="stylesheet">
        <link rel="preconnect" href="https://fonts.googleapis.com">
        <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
        <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@800&display=swap" rel="stylesheet">
        <link href="https://unpkg.com/aos@2.3.1/dist/aos.css" rel="stylesheet">
	<!--[if lt IE 9]>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/html5shiv/3.7.3/html5shiv.min.js"></script>
	<![endif]--> 
	
</head>

<body>
<nav  data-aos="fade-down" data-aos-delay="0" class="navbar navbar-expand-md navbar-light bg-light">
  <a class="navbar-brand" href="#"><img data-aos="fade-down" src="assets/img/logo.png" width="90px" height="90px"></a>
  <div class="counter" data-aos="fade-down" data-aos-delay="50">
<span style="line-height: 60px; color:#DBC651;">Aktualnie jest</span></br>
<span data-playercounter-ip="nazwamc.pl">0</span> graczy online
  </div>
  <button class="navbar-toggler custom-toggler" type="button" data-toggle="collapse" data-target="#navbarNavAltMarkup" aria-controls="navbarNavAltMarkup" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>
  <div class="collapse navbar-collapse" id="navbarNavAltMarkup">
    <div class="navbar-nav ml-auto">
      <a data-aos="fade-down" data-aos-delay="100" class="nav-item nav-link active" href="index.php" style="color:#BCBDBD; text-transform: UPPERCASE; font-weight:700;">Główna <span class="sr-only"></span></a>
      <a data-aos="fade-down" data-aos-delay="150" class="nav-item nav-link" href="tos" style="color:#BCBDBD; text-transform: UPPERCASE; font-weight:700;">Regulamin</a>
      <a data-aos="fade-down" data-aos-delay="200" class="nav-item nav-link" href="<?php echo $discord_link?>" style="color:#BCBDBD; text-transform: UPPERCASE; font-weight:700;">Discord</a>
      <a data-aos="fade-down" data-aos-delay="250" class="nav-item nav-link disabled" href="shop" tabindex="-1" style="color:#BCBDBD; text-transform: UPPERCASE; font-weight:700;">Sklep</a>
    </div>
  </div>
</nav>
<div class="container">
<div class="row"><div class="col  text-center" style="margin-top:60px;"><img src="assets/img/logo.png" width="330px" height="330px"></br>
<div class="logo-text"><?php echo $server_name;?></div>
<div class="aft-text"><?php echo $server_desc;?></div>
<a href="shop"><div class="bnt-primary "><span style="line-height: 40px;">Sklep</span></div></a><a href="#admins"><div class="bnt-primary"><span style="line-height: 40px;">Administracja</span></div></a>
</div>
</div>
<div class="row" style="margin-top:300px;"><div class="col"><span style="font-size:28px; text-transform:UPPERCASE;"><strong>Prezentacja</strong></span><div class="pr-divider"></div></div></div>
<div class="row">
  <div class="col">
<iframe class="yt-presentation" width="560" height="315" src="<?php echo $presentation_link;?>" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
  </div>
  <div class="col col-text" style="margin-top: 30px;"><span class="pre-text"><?php echo $presentation_text;?></span><a href="<?php echo $download_film_link?>"><div class="bnt-primary"><span style="line-height: 43px;">Pobierz</span></div></a></div>
  
  </div>
  <div class="row"><div class="col shop-choose text-center"><span style="text-transform: uppercase; font-size:35px; font-weight:600;">Nasze tryby</span></br><span>WYBIERZ TRYB ABY PRZEJSC DO SKLEPU</span></br><hr style="width: 350px; text-align:center; background-color:#c0b052; margin-left:auto; margin-right:auto; height:2px;"></br></br>


</div></div>
<div class="row"><div class="col-md-5 mode-container"> <div class="mode-title"><?php echo $mode1_title;?></br><hr style="width: 200px; text-align:center;   background-color:#a19550; margin-left:auto; margin-right:auto;"></div><img src="<?php echo $mode1_img_link;?>" width="220px" height="230px" style="position: relative;
top: 30%;
transform: translateY(-50%);">
  <a href="shop" style="text-decoration:none; "><div class="button-shop"><span style="line-height: 40px;">Wybieram</span></div></a>

  </div></div>
  <div class="row"><div class="col text-center team-list"><span style="text-transform: uppercase; font-size:35px; font-weight:600;">Nasz Team</span></br><span>POZNAJ GŁÓWNĄ ADMINISTRACJĘ</span></br><hr style="width: 350px; text-align:center; background-color:#c0b052; margin-left:auto; margin-right:auto; height:2px;"></br></br></div></div>
  <div class="row justify-content-center align-items-center text-center" data-aos="fade-down">
        <section id="admins"></section>
                <div class="col-6 col-lg-3 col-xxl-2 team-member">
                    <div class="slide">
                        <img src="<?php echo $avatar1_img_link;?>">
                        <h6 class="tm-rank"><?php echo $member1_role1;?><br><?php echo $member1_role2;?></h6>
                        <div class="border-ranks"></div>
                        <h5><?php echo $member1_name;?></h5>
                    </div>
                </div>
                <div class="col-6 col-lg-3 col-xxl-2 team-member">
                    <div class="slide">
                        <img src="<?php echo $avatar2_img_link;?>">
                        <h6 class="tm-rank"><?php echo $member2_role1;?><br><?php echo $member2_role2;?></h6>
                        <div class="border-ranks"></div>
                        <h5><?php echo $member2_name;?></h5>
                    </div>
                </div>
                <div class="col-6 col-lg-3 col-xxl-2 team-member">
                    <div class="slide">
                        <img src="<?php echo $avatar3_img_link;?>">
                        <h6 class="tm-rank"><?php echo $member3_role1;?><br><?php echo $member3_role2;?></h6>
                        <div class="border-ranks"></div>
                        <h5><?php echo $member3_name;?></h5>
                    </div>
                </div>
                <div class="col-6 col-lg-3 col-xxl-2 team-member">
                    <div class="slide">
                        <img src="<?php echo $avatar4_img_link;?>">
                        <h6 class="tm-rank"><?php echo $member4_role1;?><br><?php echo $member4_role2;?></h6>
                        <div class="border-ranks"></div>
                        <h5><?php echo $member4_name;?></h5>
                    </div>
                </div>

            </div>
</div>
<section id="footer">
    <div class="container">
        <div class="row">
            <div class="col-12 col-lg-4 footer-center">
                <div class="footer-center-items">
                    <h2>SOCIAL MEDIA</h2>
                    <div class="footer-items">
                        <p><i class="fas fa-circle"></i><a target="_blank"
                                href="<?php echo $discord_link;?>">DISCORD</a></p>
                        <p><i class="fas fa-circle"></i><a target="_blank"
                                href="<?php echo $facebook_link;?>">FACEBOOK</a></p>
                        <p><i class="fas fa-circle"></i><a target="_blank" href="<?php echo $youtube_link;?>">YOUTUBE</a></p>
                        <p><i class="fas fa-circle"></i><a target="_blank" href="<?php echo $tiktok_link;?>">TIKTOK</a></p>
                    </div>
                </div>
            </div>
            <div class="col-12 col-lg-4">
                <div class="footer-logo">
                    <a href="https://nazwamc.pl"><img src="assets/img/logo.png " width="250px" height="250px"></a>
                </div>
            </div>
            <div class="col-12 col-lg-4 footer-center">
                <div class="footer-center-items">
                    <h2>PRZYDATNE LINKI</h2>
                    <div class="footer-items">
                        <p><i class="fas fa-circle"></i><a href="<?php echo $website_adress;?>">STRONA GŁÓWNA</a></p>
                        <p><i class="fas fa-circle"></i><a href="<?php echo $shop_adress;?>">SKLEP</a></p>
                        <p><i class="fas fa-circle"></i><a href="<?php echo $tos_adress;?>">REGULAMIN</a>
                        </p>
                        <p><i class="fas fa-circle"></i><a href="<?php echo $contact_adress;?>">Kontakt</a></p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<section id="copyright">
    <div class="text-center">
        <h5>ⓒ 2022 <span><?php echo $server_name;?></span> Wszelkie prawa zastrzeżone.</h5>
        <h6>WYKONANIE <a target="_blank" href="https://dencode.pl">DENCODE.PL</a></h6>
    </div>
</section>   
	<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
	
	<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js" integrity="sha384-ZMP7rVo3mIykV+2+9J3UJ46jBk0WLaUAdn689aCwoqbBJiSnjAK/l8WvCWPIPm49" crossorigin="anonymous"></script>
	
	<script src="assets/js/bootstrap.min.js"></script>
	<script src="https://cdn.jsdelivr.net/gh/leonardosnt/mc-player-counter/dist/mc-player-counter.min.js"></script>
  <script src="https://unpkg.com/aos@2.3.1/dist/aos.js"></script>
  <script>
AOS.init();
</script>

</body>
</html>