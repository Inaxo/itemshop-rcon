<?php
 if(!isset($_GET["amount"]) && empty($_GET["amount"])){
  header('Location: strona-glowna');
  exit(0);
 }
require_once('mainconfig.php');
require_once('src/Rcon.php');
use Thedudeguy\Rcon;
$rcon = new Rcon($host, $port, $password, $timeout);;
$playername = $_GET["playername"];
$amount = $_GET["amount"];
$name = $_GET["name"];
if($name==$product1_name){
  $cmd = $product1_cmd;
  if(strpos($cmd, "%player%") !== false || strpos($cmd, "%product_name%") !== false){
    $cmd = str_replace("%player%", $playername, $cmd);
    $getcmd = str_replace("%product_name%", $name, $cmd);
   
   }
    else{
   $getcmd=$cmd;
   }
}else if($name==$product2_name){
  $cmd = $product2_cmd;
  if(strpos($cmd, "%player%") !== false || strpos($cmd, "%product_name%") !== false){
    $cmd = str_replace("%player%", $playername, $cmd);
    $getcmd = str_replace("%product_name%", $name, $cmd);
   
   } else{
    $getcmd=$cmd;
   }
}
else if($name==$product3_name){
  $cmd = $product3_cmd;
  if(strpos($cmd, "%player%") !== false || strpos($cmd, "%product_name%") !== false){
    $cmd = str_replace("%player%", $playername, $cmd);
    $getcmd = str_replace("%product_name%", $name, $cmd);
   
   } else{
    $getcmd=$cmd;
   }
}
else if($name==$product4_name){
  $cmd = $product4_cmd;
  if(strpos($cmd, "%player%") !== false || strpos($cmd, "%product_name%") !== false){
    $cmd = str_replace("%player%", $playername, $cmd);
    $getcmd = str_replace("%product_name%", $name, $cmd);
   
   } else{
    $getcmd=$cmd;
   }
}
else if($name==$product5_name){
  $cmd = $product5_cmd;
  if(strpos($cmd, "%player%") !== false || strpos($cmd, "%product_name%") !== false){
    $cmd = str_replace("%player%", $playername, $cmd);
    $getcmd = str_replace("%product_name%", $name, $cmd);
   
   } else{
    $getcmd=$cmd;
   }
}
else if($name==$product6_name){
  $cmd = $product6_cmd;
  if(strpos($cmd, "%player%") !== false || strpos($cmd, "%product_name%") !== false){
    $cmd = str_replace("%player%", $playername, $cmd);
    $getcmd = str_replace("%product_name%", $name, $cmd);
   
   } else{
    $getcmd=$cmd;
   }
}else{
  echo $name;
}

if ($rcon->connect())
{
  $rcon->sendCommand($getcmd);
}

?>
<!DOCTYPE html>
<html lang="pl">
<head>

	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
	
        <title><?php echo $server_name;?> | <?php echo $server_desc;?></title>
      	<meta http-equiv="X-Ua-Compatible" content="IE=edge">
        <meta name="description" content=" <?php echo $server_desc;?>">
        <meta property="og:site_name" content="<?php echo $server_name;?>">
        <meta property="og:title" content="<?php echo $server_name;?> | <?php echo $server_desc;?>">
        <meta name="author" content="DenCode.pl">
        <meta property="og:type" content="website">
        <!--  <meta property="og:url" content="https://twojanazwa.pl/"> !-->
        <meta property="og:description" content=" <?php echo $server_desc;?>">
        <meta name="theme-color" content="#a750e8">
        <link rel="icon" type="image/png" href="assets/img/favicon.png">
        <link rel="stylesheet" href="libs/bootstrap.min.css">
        <link rel="stylesheet" href="assets/css/main.css">
        <link href="https://fonts.googleapis.com/css?family=Open+Sans:400,700&amp;subset=latin-ext" rel="stylesheet">
        <link rel="preconnect" href="https://fonts.googleapis.com">
        <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
        <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@800&display=swap" rel="stylesheet">
        <link href="https://unpkg.com/aos@2.3.1/dist/aos.css" rel="stylesheet">
	<!--[if lt IE 9]>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/html5shiv/3.7.3/html5shiv.min.js"></script>
	<![endif]--> 
	
</head>
<body>
<nav  data-aos="fade-down" data-aos-delay="0" class="navbar navbar-expand-md navbar-light bg-light">
  <a class="navbar-brand" href="#"><img data-aos="fade-down" src="assets/img/logo.png" width="90px" height="90px"></a>
  <div class="counter" data-aos="fade-down" data-aos-delay="50">
<span style="line-height: 60px; color:#DBC651;">Aktualnie jest</span></br>
<span data-playercounter-ip="nazwamc.pl">0</span> graczy online
  </div>
  <button class="navbar-toggler custom-toggler" type="button" data-toggle="collapse" data-target="#navbarNavAltMarkup" aria-controls="navbarNavAltMarkup" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>
  <div class="collapse navbar-collapse" id="navbarNavAltMarkup">
    <div class="navbar-nav ml-auto">
      <a data-aos="fade-down" data-aos-delay="100" class="nav-item nav-link active" href="index.php" style="color:#BCBDBD; text-transform: UPPERCASE; font-weight:700;">Główna <span class="sr-only"></span></a>
      <a data-aos="fade-down" data-aos-delay="150" class="nav-item nav-link" href="tos" style="color:#BCBDBD; text-transform: UPPERCASE; font-weight:700;">Regulamin</a>
      <a data-aos="fade-down" data-aos-delay="200" class="nav-item nav-link" href="<?php echo $discord_link?>" style="color:#BCBDBD; text-transform: UPPERCASE; font-weight:700;">Discord</a>
      <a data-aos="fade-down" data-aos-delay="250" class="nav-item nav-link disabled" href="shop" tabindex="-1" style="color:#BCBDBD; text-transform: UPPERCASE; font-weight:700;">Sklep</a>
    </div>
  </div>
</nav>
      <div class="container cmd">
        <?php
           if(isset($_GET["amount"]) && !empty($_GET["amount"])){
               ?>
               <div class="row"><div class="col"> <h3>Twoja transakcja przebiegła pomyślnie!</h3></div></div>
           

          <?php
           }
        ?>
      </div>
      <section id="footer">
    <div class="container">
        <div class="row">
            <div class="col-12 col-lg-4 footer-center">
                <div class="footer-center-items">
                    <h2>SOCIAL MEDIA</h2>
                    <div class="footer-items">
                        <p><i class="fas fa-circle"></i><a target="_blank"
                                href="<?php echo $discord_link;?>">DISCORD</a></p>
                        <p><i class="fas fa-circle"></i><a target="_blank"
                                href="<?php echo $facebook_link;?>">FACEBOOK</a></p>
                        <p><i class="fas fa-circle"></i><a target="_blank" href="<?php echo $youtube_link;?>">YOUTUBE</a></p>
                        <p><i class="fas fa-circle"></i><a target="_blank" href="<?php echo $tiktok_link;?>">TIKTOK</a></p>
                    </div>
                </div>
            </div>
            <div class="col-12 col-lg-4">
                <div class="footer-logo">
                    <a href="https://nazwamc.pl"><img src="assets/img/logo.png " width="250px" height="250px"></a>
                </div>
            </div>
            <div class="col-12 col-lg-4 footer-center">
                <div class="footer-center-items">
                    <h2>PRZYDATNE LINKI</h2>
                    <div class="footer-items">
                        <p><i class="fas fa-circle"></i><a href="<?php echo $website_adress;?>">STRONA GŁÓWNA</a></p>
                        <p><i class="fas fa-circle"></i><a href="<?php echo $shop_adress;?>">SKLEP</a></p>
                        <p><i class="fas fa-circle"></i><a href="<?php echo $tos_adress;?>">REGULAMIN</a>
                        </p>
                        <p><i class="fas fa-circle"></i><a href="<?php echo $contact_adress;?>">Kontakt</a></p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<section id="copyright">
    <div class="text-center">
        <h5>ⓒ 2022 <span><?php echo $server_name;?></span> Wszelkie prawa zastrzeżone.</h5>
        <h6>WYKONANIE <a target="_blank" href="https://dencode.pl">DENCODE.PL</a></h6>
    </div>
</section>   
	<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
	
	<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js" integrity="sha384-ZMP7rVo3mIykV+2+9J3UJ46jBk0WLaUAdn689aCwoqbBJiSnjAK/l8WvCWPIPm49" crossorigin="anonymous"></script>
	
	<script src="assets/js/bootstrap.min.js"></script>
	<script src="https://cdn.jsdelivr.net/gh/leonardosnt/mc-player-counter/dist/mc-player-counter.min.js"></script>
  <script src="https://unpkg.com/aos@2.3.1/dist/aos.js"></script>
  <script>
AOS.init();
</script>  
</body>
</html>