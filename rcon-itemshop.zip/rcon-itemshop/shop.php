
<?php
require_once('mainconfig.php');
?>
<!DOCTYPE html>
<html lang="pl">
<head>

	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
	
    <title><?php echo $server_name;?> | <?php echo $server_desc;?></title>
      	<meta http-equiv="X-Ua-Compatible" content="IE=edge">
        <meta name="description" content=" <?php echo $server_desc;?>">
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
        <meta property="og:site_name" content="<?php echo $server_name;?>">
        <meta property="og:title" content="<?php echo $server_name;?> | <?php echo $server_desc;?>">
        <meta name="author" content="DenCode.pl">
        <meta property="og:type" content="website">
        <!--  <meta property="og:url" content="https://nazwamc.pl/"> !-->
        <meta property="og:description" content=" <?php echo $server_desc;?>">
        <meta name="theme-color" content="#a750e8">
        <link rel="icon" type="image/png" href="assets/img/favicon.png">
        <link rel="stylesheet" href="libs/bootstrap.min.css">
        <link rel="stylesheet" href="assets/css/main.css">
        <link href="https://fonts.googleapis.com/css?family=Open+Sans:400,700&amp;subset=latin-ext" rel="stylesheet">
        <link rel="preconnect" href="https://fonts.googleapis.com">
        <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
        <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@800&display=swap" rel="stylesheet">
        <link href="https://unpkg.com/aos@2.3.1/dist/aos.css" rel="stylesheet">
        <script src="https://js.stripe.com/v3/"></script>
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
        <meta http-equiv="Content-Security-Policy" content="upgrade-insecure-requests" />
	<!--[if lt IE 9]>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/html5shiv/3.7.3/html5shiv.min.js"></script>
	<![endif]--> 
	
</head>

<body>
<nav  data-aos="fade-down" data-aos-delay="0" class="navbar navbar-expand-md navbar-light bg-light">
  <a class="navbar-brand" href="#"><img data-aos="fade-down" src="assets/img/logo.png" width="90px" height="90px"></a>
  <div class="counter" data-aos="fade-down" data-aos-delay="50">
<span style="line-height: 60px; color:#DBC651;">Aktualnie jest</span></br>
<span data-playercounter-ip="nazwamc.pl">0</span> graczy online
  </div>
  <button class="navbar-toggler custom-toggler" type="button" data-toggle="collapse" data-target="#navbarNavAltMarkup" aria-controls="navbarNavAltMarkup" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>
  <div class="collapse navbar-collapse" id="navbarNavAltMarkup">
    <div class="navbar-nav ml-auto">
      <a data-aos="fade-down" data-aos-delay="100" class="nav-item nav-link active" href="index.php" style="color:#BCBDBD; text-transform: UPPERCASE; font-weight:700;">Główna <span class="sr-only"></span></a>
      <a data-aos="fade-down" data-aos-delay="150" class="nav-item nav-link" href="tos" style="color:#BCBDBD; text-transform: UPPERCASE; font-weight:700;">Regulamin</a>
      <a data-aos="fade-down" data-aos-delay="200" class="nav-item nav-link" href="<?php echo $discord_link?>" style="color:#BCBDBD; text-transform: UPPERCASE; font-weight:700;">Discord</a>
      <a data-aos="fade-down" data-aos-delay="250" class="nav-item nav-link disabled" href="shop" tabindex="-1" style="color:#BCBDBD; text-transform: UPPERCASE; font-weight:700;">Sklep</a>
    </div>
  </div>
</nav>
<div class="container">
        <div class="text-center" style="margin-top: 25px;">
            <h1 data-aos="fade-up" data-aos-delay="350">Produkty</h1>
        </div>
        <div class="shop-border" data-aos="fade-up" data-aos-delay="350"></div>
        <br><br>
        <div class="row text-center" data-aos="fade-up" data-aos-delay="400">
            <?php
                    if($product1_display==true){
                        echo '
                                                <div class="col-12 col-lg-6">
                <div class="shop-all">
                    <div class="shop-card">
                        <div class="row">
                            <div class="col-lg-5">
                                <div class="shop-card-img">
                                    <img name="image_src" id="image_src" src="'.$product1_img_link.'">
                                 
                                </div>
                            </div>
                            <div class="col-lg-7">
                                <div class="shop-card-content">
                                    <h2>'.$product1_name.'</h2>
                                    <div class="shop-card-border"></div>
                                    <div class="shop-card-content-2">
                                        <h3>OPIS</h3>
                                        <div class="shop-descripton">
                                            <p>'.$product1_desc.'</p>
                                        </div>
                                        <h4>CENA: '.$product1_price.'
                                             PLN</h4>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="shop-buy">
                        <a class="buy-now" 
                            type="button">KUP
                            TERAZ</a>
                <input type="hidden" name="image_src" id="image_src" value="'.$product1_img_link.'"/>
                <input type="hidden" name="price" id="price" value="'.$product1_price.'"/>
                <input type="hidden" name="item_name" id="item_name" value="'.$product1_name.'"/>
                    </div>
                </div>
            </div>';
                    }
        ?>            <?php
        if($product2_display==true){
            echo '
                                    <div class="col-12 col-lg-6">
    <div class="shop-all">
        <div class="shop-card">
            <div class="row">
                <div class="col-lg-5">
                    <div class="shop-card-img">
                        <img name="image_src" id="image_src" src="'.$product2_img_link.'">
                     
                    </div>
                </div>
                <div class="col-lg-7">
                    <div class="shop-card-content">
                        <h2>'.$product2_name.'</h2>
                        <div class="shop-card-border"></div>
                        <div class="shop-card-content-2">
                            <h3>OPIS</h3>
                            <div class="shop-descripton">
                                <p>'.$product2_desc.'</p>
                            </div>
                            <h4>CENA: '.$product2_price.'
                                 PLN</h4>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="shop-buy">
            <a class="buy-now" 
                type="button">KUP
                TERAZ</a>
    <input type="hidden" name="image_src" id="image_src" value="'.$product2_img_link.'"/>
    <input type="hidden" name="price" id="price" value="'.$product2_price.'"/>
    <input type="hidden" name="item_name" id="item_name" value="'.$product2_name.'"/>
        </div>
    </div>
</div>';
        }
?>
            <?php
        if($product3_display==true){
            echo '
                                    <div class="col-12 col-lg-6">
    <div class="shop-all">
        <div class="shop-card">
            <div class="row">
                <div class="col-lg-5">
                    <div class="shop-card-img">
                        <img name="image_src" id="image_src" src="'.$product3_img_link.'">
                     
                    </div>
                </div>
                <div class="col-lg-7">
                    <div class="shop-card-content">
                        <h2>'.$product3_name.'</h2>
                        <div class="shop-card-border"></div>
                        <div class="shop-card-content-2">
                            <h3>OPIS</h3>
                            <div class="shop-descripton">
                                <p>'.$product3_desc.'</p>
                            </div>
                            <h4>CENA: '.$product3_price.'
                                 PLN</h4>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="shop-buy">
            <a class="buy-now" 
                type="button">KUP
                TERAZ</a>
    <input type="hidden" name="image_src" id="image_src" value="'.$product3_img_link.'"/>
    <input type="hidden" name="price" id="price" value="'.$product3_price.'"/>
    <input type="hidden" name="item_name" id="item_name" value="'.$product3_name.'"/>
    
        </div>
    </div>
</div>';
        }
?>
                                                 <?php
        if($product4_display==true){
            echo '
                                    <div class="col-12 col-lg-6">
    <div class="shop-all">
        <div class="shop-card">
            <div class="row">
                <div class="col-lg-5">
                    <div class="shop-card-img">
                        <img name="image_src" id="image_src" src="'.$product4_img_link.'">
                     
                    </div>
                </div>
                <div class="col-lg-7">
                    <div class="shop-card-content">
                        <h2>'.$product4_name.'</h2>
                        <div class="shop-card-border"></div>
                        <div class="shop-card-content-2">
                            <h3>OPIS</h3>
                            <div class="shop-descripton">
                                <p>'.$product4_desc.'</p>
                            </div>
                            <h4>CENA: '.$product4_price.'
                                 PLN</h4>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="shop-buy">
            <a class="buy-now" 
                type="button">KUP
                TERAZ</a>
    <input type="hidden" name="image_src" id="image_src" value="'.$product4_img_link.'"/>
    <input type="hidden" name="price" id="price" value="'.$product4_price.'"/>
    <input type="hidden" name="item_name" id="item_name" value="'.$product4_name.'"/>
    
        </div>
    </div>
</div>';
        }
?>
        
        <?php
        if($product5_display==true){
            echo '
                                    <div class="col-12 col-lg-6">
    <div class="shop-all">
        <div class="shop-card">
            <div class="row">
                <div class="col-lg-5">
                    <div class="shop-card-img">
                        <img name="image_src" id="image_src" src="'.$product5_img_link.'">
                     
                    </div>
                </div>
                <div class="col-lg-7">
                    <div class="shop-card-content">
                        <h2>'.$product5_name.'</h2>
                        <div class="shop-card-border"></div>
                        <div class="shop-card-content-2">
                            <h3>OPIS</h3>
                            <div class="shop-descripton">
                                <p>'.$product5_desc.'</p>
                            </div>
                            <h4>CENA: '.$product5_price.'
                                 PLN</h4>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="shop-buy">
            <a class="buy-now" 
                type="button">KUP
                TERAZ</a>
    <input type="hidden" name="image_src" id="image_src" value="'.$product5_img_link.'"/>
    <input type="hidden" name="price" id="price" value="'.$product5_price.'"/>
    <input type="hidden" name="item_name" id="item_name" value="'.$product5_name.'"/>
    
        </div>
    </div>
</div>';
        }
?>
        
            <?php
        if($product6_display==true){
            echo '
                                    <div class="col-12 col-lg-6">
    <div class="shop-all">
        <div class="shop-card">
            <div class="row">
                <div class="col-lg-5">
                    <div class="shop-card-img">
                        <img name="image_src" id="image_src" src="'.$product6_img_link.'">
                     
                    </div>
                </div>
                <div class="col-lg-7">
                    <div class="shop-card-content">
                        <h2>'.$product6_name.'</h2>
                        <div class="shop-card-border"></div>
                        <div class="shop-card-content-2">
                            <h3>OPIS</h3>
                            <div class="shop-descripton">
                                <p>'.$product6_desc.'</p>
                            </div>
                            <h4>CENA: '.$product6_price.'
                                 PLN</h4>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="shop-buy">
            <a class="buy-now" 
                type="button">KUP
                TERAZ</a>
    <input type="hidden" name="image_src" id="image_src" value="'.$product6_img_link.'"/>
    <input type="hidden" name="price" id="price" value="'.$product6_price.'"/>
    <input type="hidden" name="item_name" id="item_name" value="'.$product6_name.'"/>
    
        </div>
    </div>
</div>';
        }
?>       
                     </div>
</div>


<section id="footer">
    <div class="container">
        <div class="row">
            <div class="col-12 col-lg-4 footer-center">
                <div class="footer-center-items">
                    <h2>SOCIAL MEDIA</h2>
                    <div class="footer-items">
                        <p><i class="fas fa-circle"></i><a target="_blank"
                                href="<?php echo $discord_link;?>">DISCORD</a></p>
                        <p><i class="fas fa-circle"></i><a target="_blank"
                                href="<?php echo $facebook_link;?>">FACEBOOK</a></p>
                        <p><i class="fas fa-circle"></i><a target="_blank" href="<?php echo $youtube_link;?>">YOUTUBE</a></p>
                        <p><i class="fas fa-circle"></i><a target="_blank" href="<?php echo $tiktok_link;?>">TIKTOK</a></p>
                    </div>
                </div>
            </div>
            <div class="col-12 col-lg-4">
                <div class="footer-logo">
                    <a href="https://nazwamc.pl"><img src="assets/img/logo.png " width="250px" height="250px"></a>
                </div>
            </div>
            <div class="col-12 col-lg-4 footer-center">
                <div class="footer-center-items">
                    <h2>PRZYDATNE LINKI</h2>
                    <div class="footer-items">
                        <p><i class="fas fa-circle"></i><a href="<?php echo $website_adress;?>">STRONA GŁÓWNA</a></p>
                        <p><i class="fas fa-circle"></i><a href="<?php echo $shop_adress;?>">SKLEP</a></p>
                        <p><i class="fas fa-circle"></i><a href="<?php echo $tos_adress;?>">REGULAMIN</a>
                        </p>
                        <p><i class="fas fa-circle"></i><a href="<?php echo $contact_adress;?>">Kontakt</a></p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<section id="copyright">
    <div class="text-center">
        <h5>ⓒ 2022 <span><?php echo $server_name;?></span> Wszelkie prawa zastrzeżone.</h5>
        <h6>WYKONANIE <a target="_blank" href="https://dencode.pl">DENCODE.PL</a></h6>
    </div>
</section>   
	<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
	
	<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js" integrity="sha384-ZMP7rVo3mIykV+2+9J3UJ46jBk0WLaUAdn689aCwoqbBJiSnjAK/l8WvCWPIPm49" crossorigin="anonymous"></script>
	
	<script src="assets/js/bootstrap.min.js"></script>
	<script src="https://cdn.jsdelivr.net/gh/leonardosnt/mc-player-counter/dist/mc-player-counter.min.js"></script>
  <script src="https://unpkg.com/aos@2.3.1/dist/aos.js"></script>
<script>
AOS.init();
</script>

     <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
     <script>
        $(document).ready(function(){
           $(".buy-now").on('click',function(e){
                e.preventDefault();
                    var image_src = $(this).closest(".shop-buy").find("#image_src").attr("value");
                    var item_name = $(this).closest(".shop-buy").find("#item_name").attr("value");
                    var price = $(this).closest(".shop-buy").find("#price").attr("value");
                    var dt = '&image='+image_src+'&item_name='+item_name+'&price='+price;
                    var url = '<?php echo $website_adress?>/checkout?'+dt; 
                  
                    $.ajax({
                         url:url,
                         method:'GET',
                         success:function(){
                              window.location.href=url;
                            
                         }
                    });
                   
                    
           });
          
        });
   </script>
</body>
</html>