<?php
header('Location: strona-glowna');
?>