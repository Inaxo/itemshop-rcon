<?php
 
/*DDDDDDDDDDDDD                                                      CCCCCCCCCCCCC                             d::::::d                    
D::::::::::::DDD                                                CCC::::::::::::C                             d::::::d                    
D:::::::::::::::DD                                            CC:::::::::::::::C                             d::::::d                    
DDD:::::DDDDD:::::D                                          C:::::CCCCCCCC::::C                             d:::::d                     
  D:::::D    D:::::D     eeeeeeeeeeee    nnnn  nnnnnnnn     C:::::C       CCCCCC   ooooooooooo       ddddddddd:::::d     eeeeeeeeeeee    
  D:::::D     D:::::D  ee::::::::::::ee  n:::nn::::::::nn  C:::::C               oo:::::::::::oo   dd::::::::::::::d   ee::::::::::::ee  
  D:::::D     D:::::D e::::::eeeee:::::een::::::::::::::nn C:::::C              o:::::::::::::::o d::::::::::::::::d  e::::::eeeee:::::ee
  D:::::D     D:::::De::::::e     e:::::enn:::::::::::::::nC:::::C              o:::::ooooo:::::od:::::::ddddd:::::d e::::::e     e:::::e
  D:::::D     D:::::De:::::::eeeee::::::e  n:::::nnnn:::::nC:::::C              o::::o     o::::od::::::d    d:::::d e:::::::eeeee::::::e
  D:::::D     D:::::De:::::::::::::::::e   n::::n    n::::nC:::::C              o::::o     o::::od:::::d     d:::::d e:::::::::::::::::e 
  D:::::D     D:::::De::::::eeeeeeeeeee    n::::n    n::::nC:::::C              o::::o     o::::od:::::d     d:::::d e::::::eeeeeeeeeee  
  D:::::D    D:::::D e:::::::e             n::::n    n::::n C:::::C       CCCCCCo::::o     o::::od:::::d     d:::::d e:::::::e           
DDD:::::DDDDD:::::D  e::::::::e            n::::n    n::::n  C:::::CCCCCCCC::::Co:::::ooooo:::::od::::::ddddd::::::dde::::::::e          
D:::::::::::::::DD    e::::::::eeeeeeee    n::::n    n::::n   CC:::::::::::::::Co:::::::::::::::o d:::::::::::::::::d e::::::::eeeeeeee  
D::::::::::::DDD       ee:::::::::::::e    n::::n    n::::n     CCC::::::::::::C oo:::::::::::oo   d:::::::::ddd::::d  ee:::::::::::::e  
DDDDDDDDDDDDD            eeeeeeeeeeeeee    nnnnnn    nnnnnn        CCCCCCCCCCCCC   ooooooooooo      ddddddddd   ddddd    eeeeeeeeeeeeee  
                                                                                                                                         */

/*116. 1. Kto bez uprawnienia albo wbrew jego warunkom rozpowszechnia cudzy utwór w wersji oryginalnej albo w postaci opracowania, artystyczne wykonanie, fonogram, wideogram lub nadanie, podlega grzywnie, karze ograniczenia wolności albo pozbawienia wolności do lat 2.*/


/*Korzystanie z tej strony jest równoznaczne z akceptacją regulaminu serwisu dencode.pl*/

/*DenCode.pl zastrzega sobie prawa autorskie do wykonania strony-zdjęcia znajdujące się na niej należą do ich prawnych właścicieli*/
/*Usunięcie tekstu udowadniającego nasze autorstwo ze stopki jest równoznaczne ze złamaniem regulaminu, a w konsekwencji z przywłaszczeniem autorstwa strony*/

/*-----------------------------------------------------------------------------------*/

/*Serwer Minecraft:*/
$host = 'localhost'; //IP serwera
$port = 25575;  // Port na jakim działa RCON                    
$password = '1234'; // Hasło RCON
$timeout = 3;   // Czas życia (Nie zmieniaj)
$server_name = 'TwojaNazwa.pl'; //Nazwa serwera
$server_desc = 'Lorem ipsum sit dolor'; // Krótki opis serwera

/*Strona*/
$website_adress = ''; //Adres strony www
$shop_adress = ''; //Adres podstrony ze sklepem
$contact_adress = ''; //Adres podstrony z formularzem kontaktowym
$tos_adress = ''; //Adres podstrony z regulaminem
$presentation_text = 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec semper mi nunc, ac tincidunt mi porta sit amet. Curabitur risus leo, facilisis aliquam mi feugiat, tempor vestibulum leo. Praesent enim turpis, placerat eu nisl et, vulputate convallis enim. Donec bibendum eros vitae ante accumsan efficitur. Suspendisse eros turpis, finibus quis nisl suscipit, rna ligula, flobortis quis, convallis quis justo. Nulla lacinia eget nunc id rhoncus. Donec ut commodo augue. Vivamus sodales pretium sem, et tincidunt diam finibus eget. Fusce sit amet erat quis dolor scelerisque fermentum.'; //Tekst wyświetlany obok filmu prezentującego serwer
$presentation_link = 'https://www.youtube.com/embed/jNQXAC9IVRw'; //Link do filmu prezentującego serwer
$download_film_link = ''; //Link do pobrania filmu prezentującego serwer

//Tryby
//W ramach pakietu lite maksymalna ilość trybów wynosi: 1
$mode1_title = 'SkyBlock'; //Nazwa trybu gry
$mode1_img_link = 'assets/img/skyblock.png'; //Link do zdjęcia trybu gry

//Sekcja administracji
$member1_name = 'Test'; //Nazwa członka administracji nr 1
$member1_role1 = 'Właściciel'; //Rola (Człon 1) członka administracji nr 1
$member1_role2 = 'Założyciel'; // Rola (Człon 2) członka administracji nr 1
$avatar1_img_link = 'https://minotar.net/armor/bust/Manolo421/100.png'; //Link do avatara członka administracji nr 1
//=====================
$member2_name = 'Test'; //Nazwa członka administracji nr 2
$member2_role1 = 'WŁAŚCICIEL'; //Rola (Człon 1) członka administracji nr 2
$member2_role2 = 'Technik'; // Rola (Człon 2) członka administracji nr 2
$avatar2_img_link = 'https://minotar.net/armor/bust/Dominowskyy/100.png';  //Link do avatara członka administracji nr 2
//=====================
$member3_name = 'Test'; //Nazwa członka administracji nr 3
$member3_role1 = 'Pomocnik'; //Rola (Człon 1) członka administracji nr 3
$member3_role2 = 'Discord Support'; // Rola (Człon 2) członka administracji nr 3
$avatar3_img_link = 'https://minotar.net/armor/bust/Naxi/100.png'; //Link do avatara członka administracji nr 3
//=====================
$member4_name = 'Test'; //Nazwa członka administracji nr 4
$member4_role1 = 'Community'; //Rola (Człon 1) członka administracji nr 4
$member4_role2 = 'Manager'; // Rola (Człon 2) członka administracji nr 4
$avatar4_img_link = 'https://minotar.net/armor/bust/Malpa/100.png'; //Link do avatara członka administracji nr 4

//Social Media
$discord_link = ''; //Link do discorda
$facebook_link = ''; //Link do facebooka
$youtube_link = ''; //Link do yt
$tiktok_link = ''; //Link do tiktoka

//Produkty
/*W ramach pakietu lite maksymalna liczba produktów wynosi: 6*/
/*Placeholdery które możesz użyć to : %player%-nick gracza i %product_name% -nazwa produktu*/
$product1_display = true; // Czy wyświetlać produkt 1: true/false
$product1_name = 'RANGA-ELITA'; //Nazwa produktu 1
$product1_desc = 'Gracz po zakupie usługi otrzyma range ELITA na serwerze!'; //Opis produktu 1
$product1_price = '30.00'; //Cena produktu 1
$product1_img_link = 'https://i.imgur.com/k7qYULF.jpeg'; //Link do zdjęcia produktu 1
$product1_cmd = 'say Gracz %player% zakupił %produkt_name%'; //Komenda, która ma się wykonać podczas zakupu
//====================================================================================
$product2_display = true; // Czy wyświetlać produkt 2: true/false
$product2_name = 'RANGA-SPONSOR'; //Nazwa produktu 2
$product2_desc = 'Gracz po zakupie usługi otrzyma range SPONSOR na serwerze!'; //Opis produktu 2
$product2_price = '20.00'; //Cena produktu 2
$product2_img_link = 'https://i.imgur.com/JjewjLC.jpeg'; //Link do zdjęcia produktu 2
$product2_cmd = ''; //Komenda, która ma się wykonać podczas zakupu
//====================================================================================
$product3_display = true; // Czy wyświetlać produkt 3: true/false
$product3_name = 'RANGA-SVIP'; //Nazwa produktu 3
$product3_desc = 'Gracz po zakupie usługi otrzyma range SVIP na serwerze!'; //Opis produktu 3
$product3_price = '10.00'; //Cena produktu 3
$product3_img_link = 'https://i.imgur.com/eVKoTCU.jpeg'; //Link do zdjęcia produktu 3
$product3_cmd = ''; //Komenda, która ma się wykonać podczas zakupu
//====================================================================================
$product4_display = true; // Czy wyświetlać produkt 4: true/false
$product4_name = 'DISCOZBROJA'; //Nazwa produktu 4
$product4_desc = 'Gracz po zakupie usługi otrzyma dostęp do discozbroi!'; //Opis produktu 4
$product4_price = '5.00'; //Cena produktu 4
$product4_img_link = 'https://i.imgur.com/g3hwywm.jpeg'; //Link do zdjęcia produktu 4
$product4_cmd = ''; //Komenda, która ma się wykonać podczas zakupu
//====================================================================================
$product5_display = true; // Czy wyświetlać produkt 5: true/false
$product5_name = 'KOLOROWY'; //Nazwa produktu 5
$product5_desc = 'Gracz po zakupie usługi otrzyma range KOLOROWY NICK na serwerze!'; //Opis produktu 5
$product5_price = '3.00'; //Cena produktu 5
$product5_img_link = 'https://i.imgur.com/LrUv0gn.jpeg'; //Link do zdjęcia produktu 5
$product5_cmd = ''; //Komenda, która ma się wykonać podczas zakupu
//====================================================================================
$product6_display = true; // Czy wyświetlać produkt 6: true/false
$product6_name = 'UNBAN'; //Nazwa produktu 6
$product6_desc = 'Gracz zostanie odbanowany na serwerze'; //Opis produktu 6
$product6_price = '10.00'; //Cena produktu 6
$product6_img_link = 'https://i.imgur.com/OEEtrcw.jpg'; //Link do zdjęcia produktu 6
$product6_cmd = ''; //Komenda, która ma się wykonać podczas zakupu  

//===================================================================================
/*Regulamin*/
$tos_par1_title = 'Postanowienia ogólne'; //Tytuł par.1 regulaminu
$tos_par1_text = 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aenean ultricies suscipit dolor vel placerat. Phasellus id tincidunt enim. Maecenas tincidunt ac nunc vel blandit. Curabitur augue magna, sollicitudin eget orci semper, finibus dignissim ipsum. Suspendisse vel nulla eleifend, mattis tortor eu, auctor leo. Proin dictum neque enim, id eleifend risus placerat ut. Aenean elit elit, commodo egestas nulla ac, posuere auctor ipsum. Maecenas pulvinar, nisl ut convallis ultricies, velit lorem ultricies nisi, sit amet semper sem orci elementum lectus. Sed auctor ligula nunc, in hendrerit felis efficitur vitae. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Mauris faucibus nisi libero, vitae rutrum tellus malesuada ut. Nulla facilisi. Donec consequat diam quis tincidunt commodo. Vestibulum vel accumsan diam. Sed ac ullamcorper lectus.';
//=======================
$tos_par2_title = 'Płatności';
$tos_par2_text = 'Dostępne formy płatności w serwisie: Przelew.</br>
Cena usługi różni się w zależności od wybranej metody i rodzaju płatności.</br>
Płatności obsługiwane są przez firmy: https://stripe.com - która odpowiada za Przelew.</br>
Wykonana transakcja nie podlega zwrotom.
  ';
  //=======================
$tos_par3_title = 'Zakazane zachowania';
$tos_par3_text = 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aenean ultricies suscipit dolor vel placerat. Phasellus id tincidunt enim. Maecenas tincidunt ac nunc vel blandit. Curabitur augue magna, sollicitudin eget orci semper, finibus dignissim ipsum. Suspendisse vel nulla eleifend, mattis tortor eu, auctor leo. Proin dictum neque enim, id eleifend risus placerat ut. Aenean elit elit, commodo egestas nulla ac, posuere auctor ipsum. Maecenas pulvinar, nisl ut convallis ultricies, velit lorem ultricies nisi, sit amet semper sem orci elementum lectus. Sed auctor ligula nunc, in hendrerit felis efficitur vitae. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Mauris faucibus nisi libero, vitae rutrum tellus malesuada ut. Nulla facilisi. Donec consequat diam quis tincidunt commodo. Vestibulum vel accumsan diam. Sed ac ullamcorper lectus.';
  //=======================
  $tos_par4_title = 'Polityka prywatności';
  $tos_par4_text = 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aenean ultricies suscipit dolor vel placerat. Phasellus id tincidunt enim. Maecenas tincidunt ac nunc vel blandit. Curabitur augue magna, sollicitudin eget orci semper, finibus dignissim ipsum. Suspendisse vel nulla eleifend, mattis tortor eu, auctor leo. Proin dictum neque enim, id eleifend risus placerat ut. Aenean elit elit, commodo egestas nulla ac, posuere auctor ipsum. Maecenas pulvinar, nisl ut convallis ultricies, velit lorem ultricies nisi, sit amet semper sem orci elementum lectus. Sed auctor ligula nunc, in hendrerit felis efficitur vitae. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Mauris faucibus nisi libero, vitae rutrum tellus malesuada ut. Nulla facilisi. Donec consequat diam quis tincidunt commodo. Vestibulum vel accumsan diam. Sed ac ullamcorper lectus.';
?>