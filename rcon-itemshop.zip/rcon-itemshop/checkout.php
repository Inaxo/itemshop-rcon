
<?php
require_once('mainconfig.php');
$check = $_GET["item_name"];
if($check==null){
    header('Location: strona-glowna');
    exit(0);
}
?>
<!DOCTYPE html>
<html lang="pl">
<head>

	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
	
    <title><?php echo $server_name;?> | <?php echo $server_desc;?></title>
      	<meta http-equiv="X-Ua-Compatible" content="IE=edge">
        <meta name="description" content=" <?php echo $server_desc;?>">
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
        <meta property="og:site_name" content="<?php echo $server_name;?>">
        <meta property="og:title" content="<?php echo $server_name;?> | <?php echo $server_desc;?>">
        <meta name="author" content="DenCode.pl">
        <meta property="og:type" content="website">
        <!--  <meta property="og:url" content="https://nazwamc.pl/"> !-->
        <meta property="og:description" content=" <?php echo $server_desc;?>">
        <meta name="theme-color" content="#a750e8">
        <link rel="icon" type="image/png" href="assets/img/favicon.png">
        <link rel="stylesheet" href="libs/bootstrap.min.css">
        <link rel="stylesheet" href="assets/css/main.css">
        <link href="https://fonts.googleapis.com/css?family=Open+Sans:400,700&amp;subset=latin-ext" rel="stylesheet">
        <link rel="preconnect" href="https://fonts.googleapis.com">
        <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
        <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@800&display=swap" rel="stylesheet">
        <link href="https://unpkg.com/aos@2.3.1/dist/aos.css" rel="stylesheet">
        <script src="https://js.stripe.com/v3/"></script>
        <script src="https://kit.fontawesome.com/331273e086.js" crossorigin="anonymous"></script>
        <script src="https://unpkg.com/boxicons@2.1.2/dist/boxicons.js"></script>
	<!--[if lt IE 9]>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/html5shiv/3.7.3/html5shiv.min.js"></script>
	<![endif]--> 
	
</head>

<body>
<nav  data-aos="fade-down" data-aos-delay="0" class="navbar navbar-expand-md navbar-light bg-light">
  <a class="navbar-brand" href="#"><img data-aos="fade-down" src="assets/img/logo.png" width="90px" height="90px"></a>
  <div class="counter" data-aos="fade-down" data-aos-delay="50">
<span style="line-height: 60px; color:#DBC651;">Aktualnie jest</span></br>
<span data-playercounter-ip="nazwamc.pl">0</span> graczy online
  </div>
  <button class="navbar-toggler custom-toggler" type="button" data-toggle="collapse" data-target="#navbarNavAltMarkup" aria-controls="navbarNavAltMarkup" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>
  <div class="collapse navbar-collapse" id="navbarNavAltMarkup">
    <div class="navbar-nav ml-auto">
      <a data-aos="fade-down" data-aos-delay="100" class="nav-item nav-link active" href="index.php" style="color:#BCBDBD; text-transform: UPPERCASE; font-weight:700;">Główna <span class="sr-only"></span></a>
      <a data-aos="fade-down" data-aos-delay="150" class="nav-item nav-link" href="#" style="color:#BCBDBD; text-transform: UPPERCASE; font-weight:700;">Regulamin</a>
      <a data-aos="fade-down" data-aos-delay="200" class="nav-item nav-link" href="<?php echo $discord_link?>" style="color:#BCBDBD; text-transform: UPPERCASE; font-weight:700;">Discord</a>
      <a data-aos="fade-down" data-aos-delay="250" class="nav-item nav-link disabled" href="shop.php" tabindex="-1" style="color:#BCBDBD; text-transform: UPPERCASE; font-weight:700;">Sklep</a>
    </div>
  </div>
</nav>
<div class="container" id="containermid">
        <div class="row" style="margin-top: 50px;"><div class="col">
        <div class="back" onclick="goback()"><i class="fa-solid fa-arrow-left-long" style="font-size: 20px; margin-top:10px;"></i> <span style="font-size: 20px;">Powrót do produktów</span></div>
        </div></div>
        <form autocomplete="off" action="checkout-charge.php" method="POST">
        <div class="row"><div class="col-4 product-left-col text-center" style="margin-left: 25px; margin-top:30px;"><img style="margin-top: 28px;" width="220px" height="220px" src="<?php echo $_GET["image"]?>"/></br></br>
        <span class="product-title" ><?php echo $_GET["item_name"];   ?></span></br>
        <span class="product-description"><?php
        
        $check = $_GET["item_name"];
            if ($check==$product1_name){
                echo $product1_desc;
            }
            else if($check==$product2_name){
                echo $product2_desc;
            }
            else if($check==$product3_name){
                echo $product3_desc;
            }
            else if($check==$product4_name){
                echo $product4_desc;
            }
            else if($check==$product5_name){
                echo $product5_desc;
            }
            else if($check==$product6_name){
                echo $product6_desc;
            }else{
                echo "Error when getting product description...";
            }
        
        ?></span>
        </div>
        <div class="col" style="margin-top: 30px; margin-left: 150px;"><div class="num-container"><span class="number">1</span></div><span class="tit">Dane</span></br></br>
                    <div class="col">Nick z gry</div><input type="text" name="nickname" class="input-text" placeholder="Wpisz tu swój nick z gry..."> <div class="col">Adres e-mail</div><input type="email" class="input-text" placeholder="Wpisz tu swój adres e-mail...">
</br>
<div class="num-container" style="margin-top: 10px;"><span class="number">2</span></div><span class="tit">Produkt</span></br></br>
<div class="title-fill"><?php echo $_GET["item_name"]?></div>
<div class="num-container" style="margin-top: 20px;"><span class="number">3</span></div><span class="tit">Metoda płatności</span></br></br>
<div id="payment-box" onclick="changeStyle()"><i class="fa-solid fa-credit-card" style="position:absolute; margin-bottom:20px;"></i>
<span style="margin-top: 50px;">Karta kredytowa</span>
</div>
<input type="hidden" name="amount" value="<?php echo $_GET["price"]?>">
<input type="hidden" name="product_name" value="<?php echo $_GET["item_name"]?>">

<script
                src="https://checkout.stripe.com/checkout.js" class="stripe-button"
                data-key="pk_test_51KC0bnGz1iGRyox3ZuYyZhAXsZ8mIpzff4AqVpsOGrfPORSeY1ebwH1gkwKG3dYajslW3aRaqpepxTWzBCqOnrjC00vDFoda8r"
                data-amount=<?php echo str_replace(",","",$_GET["price"]) * 100?>
                data-name="<?php echo $_GET["item_name"]?>"
                data-description="<?php echo $_GET["item_name"]?>"
                data-image="<?php echo $_GET["image"]?>"
                data-currency="pln"
                data-locale="pl">
                </script></br>
                <span id="payment-info" style="margin-left: 160px;">Za płatność odpowiada stripe.com</span>
</div>
       
    </div>
    </div>
</form>
<section id="footer">
    <div class="container">
        <div class="row">
            <div class="col-12 col-lg-4 footer-center">
                <div class="footer-center-items">
                    <h2>SOCIAL MEDIA</h2>
                    <div class="footer-items">
                        <p><i class="fas fa-circle"></i><a target="_blank"
                                href="<?php echo $discord_link;?>">DISCORD</a></p>
                        <p><i class="fas fa-circle"></i><a target="_blank"
                                href="<?php echo $facebook_link;?>">FACEBOOK</a></p>
                        <p><i class="fas fa-circle"></i><a target="_blank" href="<?php echo $youtube_link;?>">YOUTUBE</a></p>
                        <p><i class="fas fa-circle"></i><a target="_blank" href="<?php echo $tiktok_link;?>">TIKTOK</a></p>
                    </div>
                </div>
            </div>
            <div class="col-12 col-lg-4">
                <div class="footer-logo">
                    <a href="https://nazwamc.pl"><img src="assets/img/logo.png " width="250px" height="250px"></a>
                </div>
            </div>
            <div class="col-12 col-lg-4 footer-center">
                <div class="footer-center-items">
                    <h2>PRZYDATNE LINKI</h2>
                    <div class="footer-items">
                        <p><i class="fas fa-circle"></i><a href="<?php echo $website_adress;?>">STRONA GŁÓWNA</a></p>
                        <p><i class="fas fa-circle"></i><a href="<?php echo $shop_adress;?>">SKLEP</a></p>
                        <p><i class="fas fa-circle"></i><a href="<?php echo $tos_adress;?>">REGULAMIN</a>
                        </p>
                        <p><i class="fas fa-circle"></i><a href="<?php echo $contact_adress;?>">Kontakt</a></p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<section id="copyright">
    <div class="text-center">
        <h5>ⓒ 2022 <span><?php echo $server_name;?></span> Wszelkie prawa zastrzeżone.</h5>
        <h6>WYKONANIE <a target="_blank" href="https://dencode.pl">DENCODE.PL</a></h6>
    </div>
</section>   
	<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
	
	<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js" integrity="sha384-ZMP7rVo3mIykV+2+9J3UJ46jBk0WLaUAdn689aCwoqbBJiSnjAK/l8WvCWPIPm49" crossorigin="anonymous"></script>
	
	<script src="assets/js/bootstrap.min.js"></script>
	<script src="https://cdn.jsdelivr.net/gh/leonardosnt/mc-player-counter/dist/mc-player-counter.min.js"></script>
  <script src="https://unpkg.com/aos@2.3.1/dist/aos.js"></script>
<script>
AOS.init();
</script>

     <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>


    <script type="text/javascript">
    $(document).ready(function(){
        $(".stripe-button-el span").remove();
              $("button.stripe-button-el").removeAttr('style').css({
                "display":"inline-block",
                "padding":"15px",
                "background":"#3fb0ac",
                "color":"white",
                "font-size":"1.3em" }).html("Zakup <?php echo $_GET["price"].' PLN'?>");
        });
        
</script>
<script>
    function changeStyle(){
        
        const element = document.getElementById("payment-box");
        element.style.border = "1px solid #c0b052";
        var y = document.getElementsByClassName('stripe-button-el');
        var aNode = y[0];
        aNode.setAttribute('style', 'display:inline-block !important');
        const text = document.getElementById("payment-info");
        text.style.display = 'block';
       
    }
    </script>
    <script>
    function goback(){
        window.history.go(-1);
    }

    $('#ph').on('keypress',function(){
         var text = $(this).val().length;
         if(text > 9){
              return false;
         }else{
            $('#ph').text($(this).val());
         }
         
    });
    </script>

</body>
</html>