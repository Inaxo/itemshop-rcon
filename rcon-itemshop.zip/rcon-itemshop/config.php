<?php
    require_once "stripe-php-master/init.php";

    $stripeDetails = array(
        "secretKey" => "sk_test_51KC0bnGz1iGRyox3gEC8wWYMKfSspHaUfFY4Ie4jH6qlC2wIcJ4sdbwuJCIRxb3vhqGZa8VQyw8ClCMjV1i0NVr900RH0HNx2Z",
        "publishableKey" => "pk_test_51KC0bnGz1iGRyox3ZuYyZhAXsZ8mIpzff4AqVpsOGrfPORSeY1ebwH1gkwKG3dYajslW3aRaqpepxTWzBCqOnrjC00vDFoda8r"
    );

    \Stripe\Stripe::setApiKey($stripeDetails["secretKey"]);
?>